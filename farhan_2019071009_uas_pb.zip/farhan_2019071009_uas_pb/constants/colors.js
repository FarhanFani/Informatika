export default {
    primary: '#008000',
    secondary: '#adff2f'
};